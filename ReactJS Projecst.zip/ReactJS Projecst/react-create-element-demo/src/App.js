import React from 'react';
import logo from './logo.svg';

// import './App.css';

// class Welcome extends Component {
//   render() {
//     return (
//       <h1>Welcome to Capgemini</h1>
//     );
//   }
// }

var adharak=require('create-react-class')
var Welcome=adharak({
  render(){
    return <h1>Welcome to Capgemini</h1>
  }
})

export default Welcome;
