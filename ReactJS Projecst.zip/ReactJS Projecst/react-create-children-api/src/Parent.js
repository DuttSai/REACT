import React from 'react'
class Parent extends React.Component{
    render(){
        var count=0;
      var mapobj=React.Children.map(this.props.children,child=>(
          count++,
          <div>
              Type of element : {child.type}       
        </div>
      )); 
       console.log(mapobj)
       if(count>1){
       return <div><p>Count: {React.Children.count(this.props.children) }</p>
       <p>Parent should have only one child</p></div>
       }
       else{
        return (
            <div>
                Count: {React.Children.count(this.props.children) }
               <p> {this.props.children}</p>
                  {mapobj}
            </div>
            
        )
       }
  }  
}
export default Parent