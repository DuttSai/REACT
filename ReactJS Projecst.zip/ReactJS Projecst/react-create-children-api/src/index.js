import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Parent from './Parent';
import * as serviceWorker from './serviceWorker';

class App extends React.Component{
    render(){
        return (
            <div>
                <Parent>
                <button>Sample</button>
                    {/* <br/>
                    <button>Register</button>
                    <br/>
                    this is a sample content */}
                </Parent>
            </div>
        )
    }
} 
ReactDOM.render(<App />, document.getElementById('root'));
serviceWorker.unregister();
