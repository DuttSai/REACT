import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import App from './App';
import user from './user.jpg'
import guest from './guest.png'
import * as serviceWorker from './serviceWorker';

// ReactDOM.render(<App />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();
class App extends React.Component{
    render(){
        const value=prompt("Are you a User (Use true or false only)")
        if(value=="true")
        {
        return <h1> User : <img height="30px" width="30px" src={user} alt="User "></img></h1>
    }
        else{
        return  <h1>Guest : <img height="30px" width="30px" src={guest} alt="Guest "></img></h1>
    }
}
}
ReactDOM.render(<App />,document.getElementById('root'))