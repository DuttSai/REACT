import React from 'react'
import TheatreContext from './index'
class Screen extends React.Component{
    render(){
        // const children=value.screenNames.map((child,index)=>{
           
        //     return (<p> {child}</p>)
        // })
        return(
        <TheatreContext.Consumer >{
            (value)=>(
                <div>
                    <h3>Screen Names</h3>
                    <ul>
                        
                        {value.screenNames.map((child,i)=>{
                                return <li key={i}>{child}</li> 
                        })}                
                        
                    </ul>
                    <h3>Timings</h3>
                    <ul>
                        {value.showTimes.map((c,i)=>
                            {
                                return <li key={i}>xdasdgfmnbm,{c}</li>
                            }
                            )}
                    </ul>
                </div>
            )
        }

        </TheatreContext.Consumer>
        )
}  
}
export default Screen