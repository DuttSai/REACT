import React from 'react'
import Screen from './Screen'
import TheatreContext from './index' 
class Theatre extends React.Component{
    render(){
        return(
            <TheatreContext.Consumer>
               {
                   (value)=> (
                   <div>
                    <h3>Theatre Name:{value.theatreName}</h3>
                    <Screen/>
                </div>
                )                
            }
            </TheatreContext.Consumer>
        )
    }
}
export default Theatre