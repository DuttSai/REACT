import React from 'react'
import Theatre from './Theatre'
import TheatreContext from './index';
class Mall extends React.Component{
    state={
        theatreName:'INOX',
        screenNames:['Tiger','cheetah','Lion'],
        showTimes:['9 PM','5 PM','1 PM']
    }
    render(){
        return(
            <TheatreContext.Provider value={this.state}>
            <Theatre/>
            </TheatreContext.Provider>
        )
    }
}
export default Mall