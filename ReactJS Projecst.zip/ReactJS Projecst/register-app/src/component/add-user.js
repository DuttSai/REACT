import React, { Component } from 'react';

class Addproduct extends Component {
    constructor() {
        super();
        this.state = {
            data: {}
        }
    }

    getAllUser(event) {
        event.preventDefault()
        this.setState({
            data:
            {
                custId: this.refs.custId.value,
                custName: this.refs.custName.value,
                custMobile: this.refs.custMobile.value,
                addr:this.refs.addr.value,
                description:this.refs.description.value,
                date:this.refs.date.value
            }
        }, function () {
            this.props.getUser(this.state.data);
        }
        )
        this.refs.custId.value = "";
        this.refs.custName.value = "";
        this.refs.custMobile.value = "";
        this.refs.addr.value="";
        this.refs.description.value="";
        this.refs.date.value="";
    }

    render() {
        return (
            <div className="rform">
                    <h3>Customer Registration Form</h3>
                    <div className="fieds">
                    <form>
                           <div className="form-group"><input type="text" className="form-control"  placeholder="Username" ref="custId" /></div> 
                           <div className="form-group"><input type="email" className="form-control"  placeholder="Email id" ref="custName" /></div> 
                           <div className="form-group"><input type="number" className="form-control"  placeholder="Mobile Number" ref="custMobile" /></div> 
                          <div className="form-group"><input type="text" className="form-control"  placeholder="Address" ref="addr" /></div> 
                            <div className="form-group"><input type="text" className="form-control"  placeholder="Purpose of visit" ref="description" /></div> 
                           <div className="form-group"><input type="text" className="form-control"  placeholder="date Of Visit" ref="date" /></div> 
                            <button className="form-control btn btn-info"  onClick={this.getAllUser.bind(this)} >Log In</button>
                            <br/>
                            <br/>
                    </form>
                    </div>
                </div>
              
        );
    }
}
export default Addproduct;