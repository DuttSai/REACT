import React, { Component } from 'react';

class ShowProduct extends Component {
    constructor() {
        super();
        this.state = {
            data: {}
        }
    }

    delete(id) {
        this.setState({
            abc: this.props.showUser.splice(id, 1)
        });
    }


    render() {
        const customerData = (<div className="rform">
            {this.props.showUser.map((data, key) =>
                <p key={data.custId} >
                <p className="fstyle">Name : {data.custId}</p>
                
                <p className="fstyle">Email ID : {data.custName}</p>
                
                <p className="fstyle">Mobile Number : {data.custMobile}</p>
                
                <p className="fstyle">Address : {data.addr}</p>
                
                <p className="fstyle">Description : {data.description}</p>
                
                <p className="fstyle">Date : {data.date}</p>
                
                    {<button className="btn btn-danger" onClick={this.delete.bind(this, key)}>
                        Delete
    </button>} </p>
            )}</div>);

        return (
            <div>
                <h2>Customer Visit Information</h2>
                {customerData}
                </div>
        );
    }
}
    export default ShowProduct;