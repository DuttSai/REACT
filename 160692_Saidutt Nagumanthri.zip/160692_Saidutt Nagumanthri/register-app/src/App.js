import React, { Component } from 'react';
import './App.css';
import Adduser from './component/add-user';
import ShowUser from './component/show-user';

class App extends Component {
  constructor(){
  super();
  this.state={
    custData:[]
  }
  }
  addUser(data){
    let olddata=this.state.custData
    olddata.push(data)
    this.setState({
      custData:olddata
    })
  }
  replaceUser(data,id)
  { 
    let olddata=this.state.custData
    olddata.splice(id,1,data)
    this.setState({
      custData:olddata
    })    
  }
 
  
  render() {

    return (
      <div className="App">       
      <Adduser getUser={this.addUser.bind(this)}/> 
      <ShowUser  showUser={this.state.custData} showUser1={this.replaceUser.bind(this)}/>
      </div>
    );
  }
}

export default App;
