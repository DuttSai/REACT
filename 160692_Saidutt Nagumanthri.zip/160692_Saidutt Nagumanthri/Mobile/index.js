var fs = require("fs");
var express = require("express");
var appBody = require("body-parser");
var app = express();
app.use(appBody.json());
var router = express.Router();

var contents = fs.readFileSync("mobile.json");
var jsonContent = JSON.parse(contents);


console.log("Displaying all data from mobile.json")
console.log(JSON.stringify(jsonContent.mobile));

// start the server and by using postman see the output

// Updating mobile name based on id Default mobId is 1002
app.put("http://localhost:3000/mobile/1002",(req,res)=>{
    
});

//  Adding the value in mobile.json
app.post("http://localhost:3000/mobile",(req,res)=>{
    
});
console.log("\n Displaying mobiles belonging to a specific price range from 10,000 to 50,000");

fs.readFile("mobile.json", function (readerr, readdata) {
    if (readerr) {
        console.log("err in reading");
    }
    else {
        var allData = [];
        allData = JSON.parse(readdata);
        for (let i in allData.mobile) {
            if (allData.mobile[i].mobPrice > 10000 && allData.mobile[i].mobPrice < 50000) {
                console.log(allData.mobile[i]);
            }
        }
    }
});